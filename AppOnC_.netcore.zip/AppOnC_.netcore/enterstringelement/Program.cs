﻿using System;

class Program
{

    static void Main(string[] args)
    {
        string[,] myArray = new string[2, 3];

        for (int i = 0; i < myArray.GetLength(0); i++)
        {
            for (int j = 0; j < myArray.GetLength(1); j++)
            {
                Console.WriteLine("Y: " + i + " X: " + j);
                myArray[i, j] = Console.ReadLine();
            }
        }
        Console.WriteLine();

        for (int i = 0; i < myArray.GetLength(0); i++)
        {
            for (int j = 0; j < myArray.GetLength(1); j++)
            {
                Console.Write(myArray[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}