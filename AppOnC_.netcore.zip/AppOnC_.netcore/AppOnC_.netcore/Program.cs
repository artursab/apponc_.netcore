﻿


class Program
{
    static void Main(string[] args)
    {
        int[,] myArray = 
            {
                {34,34,6,7,4},
                {3,4,8,7,5},
                {34,4,6,9,4},
            }; 

        foreach (int i in myArray)
        {
            Console.WriteLine(i);
        }
 

    }

}
